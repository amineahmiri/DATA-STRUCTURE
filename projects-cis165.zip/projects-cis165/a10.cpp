//courseID:CIS165-001HY
//name: AMINE AHMIRI
//Prof. Wang
//Assignment#10
//Due by 4/16/2017

/*
steps
1.Input:

  ask the user to enter the sale for each store
  
2.Processing:
 
 get the sales for each store    
3.Output:

display a row of asterisks for each store
*/
#include <iostream>

using namespace std;

int main ()
{
  int sales [5];
  int sale = 0;

  for (int i=0; i< 5; i++)
 {
    cout<<"please enter sales for store number"<<i+1<<endl;
    cin>>sale;
    sales[i] = sale /100;
 }
 for (int c = 0; c < 5; c++)
 {
    cout<<"store number"<<c+1;
    for (int f =0; f<sales[c]; f++)
    {
        cout<<"*";
    }
    cout<<endl;
 }
return 0;
} 

