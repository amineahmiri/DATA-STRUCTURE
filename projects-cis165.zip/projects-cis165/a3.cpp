//courseID:CIS165-001HY
//name: AMINE AHMIRI
//Prof. Wang
//Assignment#3
//Due by 2/19/2017

/*
steps
1.Input:
  a.Adult Tickets Sold: 382
  b.Child Tickets Sold: 127
  
2.Processing: 
  a.grossRevenue=ADULT_PRICE*ticketsAdult+CHILD_PRICE*ticketsChild
  b.netRevenue=grossRevenue*THEATER_CUT
  c.distributor = grossRevenue-netRevenue
    
3.Output:
  a.Gross Box Office Profit: $ 4582.00
  b.Net Box Office Profit: $ 916.40
  c.Amount Paid to Distributor: $ 3665.60
*/

#include <iostream>


#include<iomanip>


using namespace std;

const int ADULT_PRICE=6, CHILD_PRICE=3;

const float THEATER_CUT=0.20;

string nameMovie;

int ticketsAdult, ticketsChild;

double grossRevenue, netRevenue, distributor;

int main()
{

cout<<"Enter the name of the movie: ";

getline(cin,nameMovie);

cout<<"\nEnter how many adult tickets and child tickets were bought, separated by a space: ";

cin>>ticketsAdult>>ticketsChild;

grossRevenue=ADULT_PRICE*ticketsAdult+CHILD_PRICE*ticketsChild;

netRevenue=grossRevenue*THEATER_CUT;

distributor = grossRevenue-netRevenue;

cout<<setprecision(2)<<fixed<<right;

cout<<"\n\nMovie Name: "<<setw(15)<<" \""<<nameMovie<<"\"\n";

cout<<"Adult Tickets Sold: "<<setw(18)<<ticketsAdult<<endl;

cout<<"Child Tickets Sold: "<<setw(18)<<ticketsChild<<endl;

cout<<"Gross Box Office Profit: "<<setw(14)<<"$"<<setw(6)<<grossRevenue<<endl;

cout<<"Net Box Office Profit: "<<setw(17)<<"$ "<<setw(6)<<netRevenue<<endl;

cout<<"Amount Paid to Distributor: "<<setw(11)<<"$"<<setw(6)<<distributor<<endl; 

return 0;
}

