//courseID:CIS165-001HY
//name: AMINE AHMIRI
//Prof. Wang
//Assignment#7
//Due by 4/9/2017

/*
1.input :

ask the user to enter a positive number.

2.process

sum of all the number until the number entered

3.output

output the sum of the number.

*/

#include <iostream>

using namespace std;

int main()
{
int numbers;
int sumOfallIntegers =0;
//ask the user to enter a positive integer value
cout << "Please enter a positive number\n";
cin >> numbers;
for (int i=1; i <= numbers; i++)
{
sumOfallIntegers += i;
}
cout << "The total of the number you entered is :" << sumOfallIntegers;
return 0;
}
