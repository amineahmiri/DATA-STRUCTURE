//courseID:CIS165-001HY
//name: AMINE AHMIRI
//Prof. Wang
//Assignment#9
//Due by 4/16/2017

/*
steps
1.Input:

  ask the user to enter the number of the year
  
2.Processing:
 
 get the falling rain for each yeat

3.Output:

a.display number of months
b.display total rain fall
c.average rain fall
*/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  int numYears =0;
  const  int MONTH=12;
  float totalRainfall = 0.0f;
  float rainfall = 0.0f;
  float avgRainfall = 0.0f;

  cout<<"please enter the number of years"<<endl;
  cin>>numYears;

while ( numYears<1)
    {
	 cout<<"number of years must be greather than 1 , please reenter again";
	 cin>>numYears;
    }
    
for ( int i = 1; i<=numYears;i++)
  {
  	for ( int months = 1; months<=MONTH;months++)
  	{
  		cout<<"please enter rainfall for "<<months<<" months ";
  		cin>>rainfall;
  		
  		while (rainfall<0)
  		{
  			cout<<"rainfall cannot be a negative number , please reenter a valid number";
  			cin>>rainfall;
  		}
  		
  		totalRainfall += rainfall;
  	}
  }
  
cout<<"\nNumber of months : "<<numYears*MONTH<<endl;
cout<<"total rainfall : "<<setprecision(2)<<fixed<<totalRainfall<<"inches"<<endl;
cout<<"average rainfall: "<<setprecision(2)<<fixed<<totalRainfall / (numYears * MONTH)<<"inches.";
return 0;
}

