/* Consider the Passenger data structure we discussed previously.
 Write a C++ program to handle the single function of inputting data.
 Create a structure in C++ to support the following items of information:
   -  Passenger Name
   -  Ticket Number
   -  Frequent Flyer Number (valid alphanumeric or N/A)
   -  Ticket Price
   -  Flight Number
   -  Seat Location
   -  Flight Date
 Choose reasonable data types and sizes.
 Write the user interface that will allow the user to specify a set of values and print the values.
 Do not worry about validation rules or error handling.  Limit yourself to the requirements of the program. */






#include<iostream>
#include<stdlib.h>

using namespace std;

//Creating a structure for our program

struct Passenger
{
    //String data type selected for Passenger_Name as Name is big char array
    char Passenger_Name[25] ;
    //Int data type selected for ticket_number as ticket number is long integer
    int ticket_number;
    //String data type selected for Frequent_Flyer_number as it is generally a string
    char Frequent_Flyer_number[25];
    //Double ticket_Price selected as ticket_Price can be integer or decimal
    double ticket_Price ;
    //Integer data type selected for flight number
    int flight_number;
    //Integer data type selected for seat
    int seat_location ;
    //Integer data type for date
    int flight_date ;
};


//Driver program for the code
int main(){
    //Creating a variable for Passenger
    Passenger P;
    
    //Receive all data from Passenger
    std::cout<< "Enter Passenger Name:\n";
    std::cin>>P.Passenger_Name;
    
    std::cout<<"Enter the ticket Number:\n";
    std::cin>>P.ticket_number;
    
    std::cout<<"Enter Frequent Flyer Number:\n";
    std::cin>>P.Frequent_Flyer_number;

    
    std::cout<<"Enter flight number\n:";
    std::cin>>P.flight_number;
    
    std::cout<<"Enter seat_location\n";
    std::cin>>P.seat_location;
    
    std::cout<<"Enter Flight date:\n";
    std::cin>>P.flight_date;
    
    //Printing all details of the Passenger
    
    std::cout<<"The Name of the Passenger is :"<<P.Passenger_Name;
    std::cout<<"\n";
    
    std::cout<<"The Ticket Number of the Passenger is :"<<P.ticket_number;
    std::cout<<"\n";
    
    std::cout<<"The Frequent Flyer Number of the Passenger is: "<<P.Frequent_Flyer_number;
    std::cout<<"\n";
    
    
    
    std::cout<<"The Flight number of the Passenger is: "<<P.flight_number;
    std::cout<<"\n";
    
    
    std::cout<<"The Seat Location of the Passenger is: "<<P.seat_location;
    std::cout<<"\n";
    
    std::cout<<"The Flight Date of the Passenger is :"<<P.flight_date;
    std::cout<<"\n";
    
    return 0;
    
}
