//courseID:CIS165-001HY
//name: AMINE AHMIRI
//Prof. Wang
//Assignment#10
//Due by 4/30/2017

/*
steps
1.Input:

  ask the user to enter a number
  
2.Processing:
 
 get the numbers from the user
 
3.Output:
 
display the largest and smallest numbers on the sreen
display a 
*/
#include <iostream>

using namespace std;

int main ()
{
	int numbers [10];
	int smallest = 0;
	int largest = 0;
	int temp = 0;
	
	
	for (int i = 0;  i<10; i++)
	{
		cout<<" Please enter a value for number "<<i +1<<" : "<<endl;  //ask the user to enter a number
		cin>>numbers[i];
		
	}
	
	
	smallest = numbers[0];
	largest = numbers[0];
	
	for (int i=1; i<10; i++)
	{
		temp = numbers[i];
		
		if (temp < smallest)
		smallest = temp;
		
		if (temp > largest)
		largest = temp;
	}
	
	cout<<" The largest number is "<<largest<<endl;
	cout<<"and the smallest number is "<<smallest<<endl;
}
