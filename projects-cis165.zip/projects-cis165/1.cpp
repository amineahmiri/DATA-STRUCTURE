//courseID:CIS165-001HY
//name: AMINE AHMIRI
//Prof. Wang
//Assignment#1
//Due by 2/12/2017

/*
steps
1.Input:
  a.number1
  b.number2
  c.sum
  
2.Processing:
a.number1 = 62
b.number2 = 99
c.sum total = number1 + number2
    
3.Output:
  total
*/

#include <iostream>
using namespace std;

int main()
{
 //input :two number to be summed
 
        int number1 = 62;
        int number2 = 99;
        
 //processing : the summing
 number1 = 62;
 number2 = 99;
 int total = number1 + number2;
 
 //output: total
    cout<<"The Total of two numbers is : "<<total;
    return 0
}
