//  Created by amine ahmiri on 5/31/17.
//  Copyright © 2017 amine ahmiri. All rights reserved.
//

//courseID:CIS165-001HY
//name: AMINE AHMIRI
//Prof. Wang
//Assignment#1
//Due by 2/12/2017


#include <iostream>
using namespace std;

double getSales (string);
void findHigher (double,double,double,double);

int main()
{
    
    double NEsales = 0.0, SEsales = 0.0, NWsales = 0.0, SWsales = 0.0;
    for ( int i = 0; i<4; i++)
    {
        switch (i) {
            case 0:
                NEsales = getSales ("NE");
                break;
            case 1:
                
                SEsales = getSales ("SE");
                break;
            case 2:
                
                NWsales = getSales ("NW");
                break;
            case 3:
                
                SWsales = getSales ("SW");
                break;21
                
            default:
                break;
        }
    }
    
    findHigher( NEsales,SEsales, NWsales,SWsales);
}
double getSales (string name)
{
    double sales = 0;
    
    cout<<"please enter sales for division "<< name <<" in dollars .";
    cin>>sales;
    while (sales<0)
    {
        cout<<"sales cannot be a negative number. Please re-enter a valid number in dollars";
        cin>>sales;
    }
    return sales;
}
void findHigher ( double NEsales,double SEsales,double NWsales,double SWsales)
{
    double highest = 0;
    string division = "";
    
    if (NEsales > SEsales && NEsales > NWsales &&SEsales > SWsales )
    {
        highest = NEsales;
        division = "north east";
        
    }
    else if (NEsales > NEsales && SEsales > NWsales && SEsales > SWsales )
    {
        highest = SWsales;
        division = "south east";
    }
    else if ( NWsales > NEsales && NWsales > SEsales && NWsales > SWsales )
    {
        highest = NWsales;
        division = "north west";
    }
    else
    {
        highest = SWsales;
        division = "south west";
    }
    
    cout << " The division with the highest sales is " << division << " with total sales of "<< highest <<" dollars .";
}



