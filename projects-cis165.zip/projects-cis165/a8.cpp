//courseID:CIS165-001HY
//name: AMINE AHMIRI
//Prof. Wang
//Assignment#8
//Due by 4/9/2017

/*
1.input :

a.get the speed of the vehicle
b.how many hour travel

2.process

Distance = speed * time

3.output

output the distance driven in mile per hour.
*/

#include <iostream>

using namespace std;

int main()
{
float distance;
float speed;
int time;

//ask the user to enter the speed
cout<<"what is the speed of the vehicle ?";
cin>>speed;

while (speed <=0 )
{
cout<<"this vehicle is not moving,please enter speed again";
cin>>speed; 
}
//ask the user to enter the time
cout<<"how many hours did it travel ?";
cin>>time;

while (time<1)
{
cout<<"time of travel must be greater than zero , please enter the time travel again";
cin>>time;
}
cout<<"\nHour\tDistance Traveled\n";
cout<<"______________________________\n";

for ( int i = 1; i<=time; i++)
{
	distance = speed * i;
	cout<<i<<"\t\t"<<distance<<endl;
}
return 0;
}
