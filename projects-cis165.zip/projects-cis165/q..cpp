//courseID:CIS165-001HY
//name: AMINE AHMIRI
//Prof. Wang
//Assignment#10
//Due by 4/23/2017

/*
steps
1.Input:
a.ask the user to enter the number of floors
b.the number of rooms on the floor
c.the number of occupied rooms  
2.Processing:
a.get the number of floor
b.get the number of rooms on the floor
c.the number of occupied rooms    
3.Output:
a.the total floor
b.total number of rooms
c.total occupied rooms
d.the available rooms in hotel
e.the percentage of the rooms occupied.
*/
#include <iostream>
#include <iomanip>

using namespace std;
int main ()
{
 int roomsonfloor = 0;
 int totalrooms = 0;
 int totalfloors = 0; 
 int totaloccupiedrooms = 0;
 int occupiedroomsonfloor = 0; 
 float percentoccupied = 0.0f;
 
 cout<<"enter the number of floors :";
 cin>>totalfloors;
 
 while (totalfloors<1)
 {
 	cout<<"numbers of floors must be a least 1";
 	cin>>totalfloors;
 }
 
 for (int i = 1; i<=totalfloors;i++)
 {
 	if ( i !=13)
 	{
 		cout<<"enter the number of rooms on the floors :";
 		cin>> roomsonfloor;
 		while (roomsonfloor<10)
 		{
 			cout<<"number of floors must be greater than 10 please re-enter ";
 			cin>>roomsonfloor;
 		}
 	}
 	
 	cout<<"how many rooms are occupied ?";
 	cin>>occupiedroomsonfloor;
 	
 	totalrooms += roomsonfloor;
 	
 	totaloccupiedrooms += occupiedroomsonfloor;
 }
 
 percentoccupied = (totaloccupiedrooms * 1.0f / totalrooms)*100.0f;
 
 cout << "the hotel has total of " << totalfloors<<"floors\n";
 cout << "the hotel has total of " << totalrooms<<"rooms\n";
 cout << "there are "<< totaloccupiedrooms << " rooms occupied\n";
 cout<<"there are "<<totalrooms - totaloccupiedrooms << " empty rooms.\n";
 cout<<"percentage of occupied rooms is " << setprecision (2)<<fixed<<percentoccupied<<"percent\n";
 
return 0;
}
