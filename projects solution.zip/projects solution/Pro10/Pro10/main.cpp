// Chapter 11, Programming Challenge 1: Movie Data
#include <iostream>
#include <string>
using namespace std;

struct MovieData
{
    string title;    // Movie title
    string director; // Director
    int year;        // Year released
    int length;      // Running time in minutes
};

// Function prototype
void displayMovie(MovieData);

int main()
{
    // Create two MovieData variables.
    MovieData movie1, movie2;
    
    // Assign values to movie1's members.
    movie1.title = "War of the Worlds";
    movie1.director = "Byron Haskin";
    movie1.year = 1953;
    movie1.length = 88;
    
    // Assign values to movie2's members.
    movie2.title = "War of the Worlds";
    movie2.director = "Stephen Spielberg";
    movie2.year = 2005;
    movie2.length = 118;
    
    // Display movie1's data.
    displayMovie(movie1);
    cout << endl;
    
    // Display movie2's data.
    displayMovie(movie2);
    
    return 0;
}

//*****************************************************
// The displayMovie function displays the data in the *
// member variables of the MovieData structure passed *
// as an argument.                                    *
// ****************************************************

void displayMovie(MovieData m)
{
    cout << "\nTitle       : " << m.title;
    cout << "\nDirector    : " << m.director;
    cout << "\nReleased    : " << m.year;
    cout << "\nRunning Time: " << m.length
    << " minutes" << endl;
}
