// Chapter 10, Programming Challenge 18: Phone Number List
/* NOTE TO BORLAND C++ BUILDER 5 USERS:
 The getline(cin, str) function in Borland C++ Builder 5 somehow
 corrupts the string read so that the find(string, pos) member function
 fails to work. Using find(string.data(), pos) seems to get around the
 difficulty
 */


#include <iostream>
#include <string>
using namespace std;

int main()
{
    const int SIZE = 11;
    string  name; //name to look for
    string  phoneDirectory[SIZE] = {
        "Renee Javens, 678-1223",
        "Joe Looney, 586-0097",
        "Geri Palmer, 223-8787",
        "Lynn Presnell, 887-1212",
        "Bill Wolfe, 223-8878",
        "Sam Wiggins, 486-0998",
        "Bob Kain, 586-8712",
        "Tim Haynes, 586-7676",
        "John Johnson, 223-9037",
        "Jean James, 678-4939",
        "Ron Palmer, 486-2783" };
    
    // Get a name or partial name to search for.
    cout << "Enter a name or partial name to search for: ";
    getline(cin, name);
    
    cout << "\nHere are the results of the search: " << endl;
    int numberEntriesFound = 0;
    
    for (int k = 0; k < SIZE; k++)
    {
        if (phoneDirectory[k].find(name.data(), 0) < phoneDirectory[k].length())
        {
            numberEntriesFound ++;
            cout << phoneDirectory[k] << endl;
        }
    }
    if (numberEntriesFound == 0)
        cout << "\nNo Entries were found for " << name;
    return 0;
}
