//
//  main.cpp
//  discretmath
//
//  Created by amine ahmiri on 12/16/17.
//  Copyright © 2017 amine ahmiri. All rights reserved.
//

#include <iostream>

using namespace std;

bool isAlpha(string input){
    for(int i = 0; i < input.length(); i++)
        if(input[i] != '0' && input[i] != '1')
            return true;
    return false;
}

int main() {
    
    cout << "Enter 0 to exit:\n";
    
    
    while(true){
        
        string input, key = "1101";
        
        cout<<"Enter an input string: \n";
        
        cin >> input;
        
        if(input == "0")
            
            break;
        if(!isAlpha(input)){
            
            if (input.find(key) != string::npos)
                
                cout << "String is ACCEPTED\n";
            
            else
                
                cout << "String is NOT ACCEPTED\n";
            
        }
        else
            
            cout << "String is NOT ACCEPTED\n";
    }
    
}
