// Chapter 10, Programming Challenge 1: String Length
#include <iostream>
using namespace std;

// Function prototype
int stringLength(char *);

int main()
{
    // Constant for the array size
    const int SIZE = 81;
    
    // An array to hold a string
    char string[SIZE];
    
    // Get a string from the user.
    cout << "\nPlease enter a string of 80 characters "
    << "or less: " << endl;
    cin.getline(string, SIZE);
    
    // Use the stringLength function to get the
    // length of the string.
    cout << "\nThe length of that string is: "
    << stringLength(string) << endl;
    return 0;
}

// ********************************************************
// The stringLength function accepts a pointer to a       *
// C-string and returns the number of characters in the   *
// string.                                                *
// ********************************************************

int stringLength(char *str)
{
    int len = 0;  // The length of the string
    
    // Step through the string. Increment
    // len until we find a null character.
    while (*str++ != '\0')
        len++;
    
    // Return the length.
    return len;
}
