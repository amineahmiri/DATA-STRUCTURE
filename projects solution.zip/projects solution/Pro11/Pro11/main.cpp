// Chapter 11, Programming Challenge 11: Monthly Budget
#include <iostream>
#include <iomanip>
using namespace std;

// Constants for budget amounts
const double HOUSING   = 500.0;
const double UTIL      = 150.0;
const double HOUSEHOLD =  65.0;
const double TRANSPORT =  50.0;
const double MEDICAL   =  30.0;
const double INSURANCE = 100.0;
const double ENTERTAIN = 150.0;
const double CLOTHING  =  75.0;
const double MISC      =  50.0;

// Structure declaration
struct MonthlyBudget
{
    double housing;
    double util;
    double household;
    double transport;
    double medical;
    double insurance;
    double entertain;
    double clothing;
    double misc;
};

// Function prototypes
void getMonthlyBudget(MonthlyBudget &);
void displayMonthlyReport(const MonthlyBudget &);

int main()
{
    // Create a MonthlyBudget variable.
    MonthlyBudget budget;
    
    // Populate the variable with data.
    getMonthlyBudget(budget);
    
    // Display a budget report.
    displayMonthlyReport(budget);
    
    return 0;
}

//**************************************************
// The getMonthlyBudget function prompts the user  *
// for the amount spent in each budget category.   *
//**************************************************

void getMonthlyBudget(MonthlyBudget &mb)
{
    // Get the amount spent for housing.
    cout << "Enter the amount spent for housing: ";
    cin >> mb.housing;
    
    // Get the amount spent for utilities.
    cout << "Enter the amount spent for utilities: ";
    cin >> mb.util;
    
    // Get the amount spent for household expenses.
    cout << "Enter the amount spent for household expenses: ";
    cin >> mb.household;
    
    // Get the amount spent for transportation.
    cout << "Enter the amount spent for transportation: ";
    cin >> mb.transport;
    
    // Get the medical expenses.
    cout << "Enter the medical expenses: ";
    cin >> mb.medical;
    
    // Get the amount spent for insurance.
    cout << "Enter the amount spent for insurance: ";
    cin >> mb.insurance;
    
    // Get the amount spent for entertainment.
    cout << "Enter the amount spent for entertainment: ";
    cin >> mb.entertain;
    
    // Get the amount spent for clothing.
    cout << "Enter the amount spent for clothing: ";
    cin >> mb.clothing;
    
    // Get the miscellaneous expenses.
    cout << "Enter the miscellaneous expenses: ";
    cin >> mb.misc;
}

//*******************************************************
// The displayMonthlyReport function displays a report  *
// showing the amount over or under budget in each      *
// budget category, as well as in the entire budget.    *
//*******************************************************

void displayMonthlyReport(const MonthlyBudget &mb)
{
    // The overUnder variable holds the amount that
    // the student is over or under budget.
    double overUnder = 0.0;
    
    // Set up the floating-point formatting.
    cout << setprecision(2) << fixed << showpoint;
    
    // Display the report headings.
    cout << setw(18) << left << "\nCategory"
    << setw(10) <<  right << "Budgeted"
    << setw(10) <<  right << "Spent"
    << setw(16) <<  right << "Over(-)/Under"
    << endl;
    cout << "-----------------------------------"
    << "----------------------\n";
    
    // Get the budget amounts for housing.
    cout << setw(18) << left << "Housing"
    << setw(10) << right << HOUSING
    << setw(10) <<  right << mb.housing
    << setw(16) <<  right
    << (HOUSING - mb.housing)
    << endl;
    // Get the amount over/under for housing.
    overUnder += (HOUSING - mb.housing);
    
    // Get the budget amounts for utilities.
    cout << setw(18) << left << "Utilities"
    << setw(10) <<  right << UTIL
    << setw(10) <<  right << mb.util
    << setw(16) <<  right << (UTIL - mb.util)
    << endl;
    // Get the amount over/under for utilities.
    overUnder += (UTIL - mb.util);
    
    // Get the budget amounts for household expenses.
    cout << setw(18) << left << "Household"
    << setw(10) <<  right << HOUSEHOLD
    << setw(10) <<  right << mb.household
    << setw(16) <<  right
    << (HOUSEHOLD - mb.household)
    << endl;
    // Get the amount over/under for household.
    overUnder += (HOUSEHOLD - mb.household);
    
    // Get the budget amounts for transportation.
    cout << setw(18) << left << "Transportation"
    << setw(10) <<  right << TRANSPORT
    << setw(10) <<  right << mb.transport
    << setw(16) <<  right
    << (TRANSPORT - mb.transport)
    << endl;
    // Get the amount over/under for transportation.
    overUnder += (TRANSPORT - mb.transport);
    
    // Get the budget amounts for medical.
    cout << setw(18) << left << "Medical"
    << setw(10) <<  right << MEDICAL
    << setw(10) <<  right << mb.medical
    << setw(16) <<  right
    << (MEDICAL - mb.medical)
    << endl;
    // Get the amount over/under for medical.
    overUnder += (MEDICAL - mb.medical);
    
    // Get the budget amounts for insurance.
    cout << setw(18) << left << "Insurance"
    << setw(10) <<  right << INSURANCE
    << setw(10) <<  right << mb.insurance
    << setw(16) <<  right
    << (INSURANCE - mb.insurance)
    << endl;
    // Get the amount over/under for insurance.
    overUnder += (INSURANCE - mb.insurance);
    
    // Get the budget amounts for entertainment.
    cout << setw(18) << left << "Entertainment"
    << setw(10) <<  right << ENTERTAIN
    << setw(10) <<  right << mb.entertain
    << setw(16) <<  right
    << (ENTERTAIN - mb.entertain)
    << endl;
    // Get the amount over/under for entertain.
    overUnder += (ENTERTAIN - mb.entertain);
    
    // Get the budget amounts for clothing.
    cout << setw(18) << left << "Clothing"
    << setw(10) <<  right << CLOTHING
    << setw(10) <<  right << mb.clothing
    << setw(16) <<  right
    << (CLOTHING - mb.clothing)
    << endl;
    // Get the amount over/under for clothing.
    overUnder += (CLOTHING - mb.clothing);
    
    // Get the budget amounts for misc.
    cout << setw(18) << left << "Miscellanous"
    << setw(10) <<  right << MISC
    << setw(10) <<  right << mb.misc
    << setw(16) <<  right
    << (MISC - mb.misc)
    << endl;
    // Get the amount over/under for misc.
    overUnder += (MISC - mb.misc);
    
    // Display the amount over/under budget for
    // the entire month.
    if (overUnder >= 0)
    {
        cout << "For the month you are under "
        << "budget by $" << overUnder
        << endl;
    }
    else
    {
        cout << "For the month you are over "
        << "budget by $" << overUnder
        << endl;
    }
}
